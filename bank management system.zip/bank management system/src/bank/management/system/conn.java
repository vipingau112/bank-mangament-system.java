package bank.management.system;

import java.sql.*;


public class conn {
   Connection connection;
   public Statement statement;

    public conn(){
        try{

          connection= DriverManager.getConnection  ("jdbc:mysql://localhost:3306/manage","root","@#!!vipin@@##*7309930194");
            statement = connection.createStatement();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
