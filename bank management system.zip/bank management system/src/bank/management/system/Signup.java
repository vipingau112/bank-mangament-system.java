package bank.management.system;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Signup extends JFrame implements ActionListener {
    JRadioButton r1, r2, m1, m2, m3;
    JTextField textname, textfname, textemail, textmartial, textaddress, textcity, textstate, textpin;
    JButton next;

    JDateChooser dateChooser;
    Random ran = new Random();
    long first4 = (ran.nextLong() % 9000L) + 1000L;
    String first = " " + Math.abs(first4);

    Signup() {
        super("APPLICATION FORM");
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(25, 10, 100, 100);
        add(image);

        JLabel labelFormno = new JLabel("APPLICATION FORM NO." + first);
        labelFormno.setBounds(160, 20, 600, 40);
        labelFormno.setFont(new Font("Raleway", Font.ITALIC, 38));
        add(labelFormno);

        JLabel label2 = new JLabel("page 1");
        label2.setFont(new Font("Raleway", Font.ITALIC, 25));
        label2.setBounds(380, 63, 300, 30);
        add(label2);


        JLabel label3 = new JLabel("Personal Detail");
        label3.setFont(new Font("Raleway", Font.ITALIC, 30));
        label3.setBounds(310, 90, 700, 40);
        add(label3);


        JLabel labelname = new JLabel("Name");
        labelname.setFont(new Font("Raleway", Font.ITALIC, 20));
        labelname.setBounds(100, 190, 100, 30);
        add(labelname);

        textname = new JTextField();
        textname.setFont(new Font("Raleway", Font.ITALIC, 14));
        textname.setBounds(300, 190, 450, 30);
        add(textname);

        JLabel labelfname = new JLabel("father's Name: ");
        labelfname.setFont(new Font("Raleway", Font.ITALIC, 20));
        labelfname.setBounds(100, 240, 200, 30);
        add(labelfname);

        textfname = new JTextField();
        textfname.setFont(new Font("Raleway", Font.ITALIC, 14));
        textfname.setBounds(300, 240, 450, 30);
        add(textfname);

        JLabel dob = new JLabel("Date of Birth : ");
        dob.setFont(new Font("Raleway", Font.ITALIC, 20));
        dob.setBounds(100, 280, 200, 30);
        add(dob);
        dateChooser = new JDateChooser();
        dateChooser.setForeground(new Color(105, 105, 105));
        dateChooser.setBounds(305, 280, 400, 30);
        add(dateChooser);

        JLabel labelgender = new JLabel("Gender : ");
        labelgender.setFont(new Font("Raleway", Font.ITALIC, 20));
        labelgender.setBounds(100, 330, 230, 23);
        add(labelgender);

        r1 = new JRadioButton("Male");
        r1.setFont(new Font("Raleway", Font.ITALIC, 13));
        r1.setBackground(new Color(222, 255, 228));
        r1.setBounds(300, 330, 65, 30);
        add(r1);
        r2 = new JRadioButton("Female ");
        r2.setFont(new Font("Raleway", Font.ITALIC, 13));
        r2.setBackground(new Color(222, 255, 228));
        r2.setBounds(550, 330, 80, 30);
        add(r2);

        JLabel labelemail = new JLabel("Email Addres: ");
        labelemail.setFont(new Font("Raleway", Font.ITALIC, 20));
        labelemail.setBounds(100, 390, 200, 30);
        add(labelemail);

        textemail = new JTextField();
        textemail.setFont(new Font("Raleway", Font.ITALIC, 14));
        textemail.setBounds(300, 395, 450, 30);
        add(textemail);


        JLabel labelmartial = new JLabel("Marriege status: ");
        labelmartial.setFont(new Font("Raleway", Font.ITALIC, 20));
        labelmartial.setBounds(100, 440, 200, 30);
        add(labelmartial);


        m1 = new JRadioButton("Married:  ");
        m1.setFont(new Font("Raleway", Font.ITALIC, 13));
        m1.setBackground(new Color(222, 255, 228));
        m1.setBounds(300, 440, 100, 30);
        add(m1);
        m2 = new JRadioButton("Unmarried ");
        m2.setFont(new Font("Raleway", Font.ITALIC, 13));
        m2.setBackground(new Color(222, 255, 228));
        m2.setBounds(550, 440, 100, 30);
        add(m2);
        JLabel labeladdress = new JLabel("Address: ");
        labeladdress.setFont(new Font("Raleway", Font.ITALIC, 20));
        labeladdress.setBounds(100, 500, 200, 30);
        add(labeladdress);

        textaddress = new JTextField();
        textaddress.setFont(new Font("Raleway", Font.ITALIC, 14));
        textaddress.setBounds(293, 508, 460, 30);
        add(textaddress);

        JLabel labelcity = new JLabel("City: ");
        labelcity.setFont(new Font("Raleway", Font.ITALIC, 20));
        labelcity.setBounds(100, 565, 200, 30);
        add(labelcity);


        textcity = new JTextField();
        textcity.setFont(new Font("Raleway", Font.ITALIC, 14));
        textcity.setBounds(293, 570, 460, 30);
        add(textcity);

        JLabel labelstate = new JLabel("State: ");
        labelstate.setFont(new Font("Raleway", Font.ITALIC, 20));
        labelstate.setBounds(100, 610, 200, 30);
        add(labelstate);

        textstate = new JTextField();
        textstate.setFont(new Font("raleway", Font.ITALIC, 14));
        textstate.setBounds(293, 610, 460, 30);
        add(textstate);

        JLabel labelpincode = new JLabel("Pin Code: ");
        labelpincode.setFont(new Font("Raleway", Font.ITALIC, 20));
        labelpincode.setBounds(100, 650, 200, 30);
        add(labelpincode);

        textpin = new JTextField();
        textpin.setFont(new Font("Raleway", Font.ITALIC, 20));
        textpin.setBounds(293, 650, 190, 30);
        add(textpin);


        ButtonGroup buttonGroup1 = new ButtonGroup();
        buttonGroup1.add(r1);
        buttonGroup1.add(r2);
        ButtonGroup buttonGroup2 = new ButtonGroup();
        buttonGroup2.add(m1);
        buttonGroup2.add(m2);

        next = new JButton("Next");
        next.setFont(new Font("Raleway", Font.ITALIC, 20));
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setBounds(670, 710, 80, 30);
        next.addActionListener(this);
        add(next);


        getContentPane().setBackground(new Color(222, 255, 228));
        setLayout(null);
        setSize(850, 800);
        setLocation(360, 40);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String formno = first;
        String name = textname.getText();
        String fname = textfname.getText();
        String dob = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
        String gender = null;

        if (r1.isSelected()) {
            gender = "Male";

        } else if (r2.isSelected()) {
            gender = "Female";

        }
        String martial = "null";

        if (m1.isSelected()) {
            martial = "married";

        } else if (m2.isSelected()) {
            martial = "unmarried";
        }


        String email = textemail.getText();
        String address = textaddress.getText();
        String city = textcity.getText();
        String pincode = textpin.getText();
        String state = textstate.getText();
        try {
            if (textname.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "fill all the fields");
            } else {
                conn conn1 = new conn();

                String q = "insert into sign values('" + formno + "','" + name + "','" + fname + "','" + dob + "','" + gender + "','" + email + "','" + martial + "','" + address + "','" + city + "','" + pincode + "','" + state + "')";
                conn1.statement.executeUpdate(q);
                new Signup2(formno);
                setVisible(false);

            }


        } catch (Exception E) {
            E.printStackTrace();
        }

    }
        public static void main (String[]args){
            new Signup();
        }

    }
